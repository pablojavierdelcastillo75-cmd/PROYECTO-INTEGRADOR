import React from 'react';
import { ShoppingBag, ScrollText, Flame, FlaskConical } from 'lucide-react';

export const Hero: React.FC = () => {
  return (
    <section id="inicio" className="relative pt-32 pb-20 lg:pt-40 lg:pb-32 overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 z-0 pointer-events-none">
        <div className="absolute top-0 right-0 w-1/2 h-full bg-gradient-to-l from-primary/10 to-transparent dark:from-primary/5 rounded-l-full transform translate-x-1/4"></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          
          {/* Text Content */}
          <div className="order-2 lg:order-1 space-y-8">
            <div className="inline-flex items-center space-x-2 bg-primary/10 dark:bg-primary/20 text-primary px-4 py-1.5 rounded-full text-sm font-bold tracking-wide uppercase">
              <Flame className="w-4 h-4" />
              <span>100% Horneado</span>
            </div>
            
            <h1 className="font-display text-5xl lg:text-7xl font-bold leading-tight text-text-light dark:text-white">
              El Poder del <br />
              <span className="text-primary italic">Chocho Andino</span>
            </h1>
            
            <p className="text-lg text-gray-600 dark:text-gray-300 max-w-lg leading-relaxed">
              Descubre una alternativa de alto aporte proteico y bajo contenido graso. Chips crujientes de <span className="italic font-serif">Lupinus mutabilis</span>, horneados a la perfección para tu bienestar.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <button className="bg-primary hover:bg-opacity-90 text-white px-8 py-4 rounded-xl font-bold text-lg shadow-xl shadow-primary/20 hover:translate-y-[-2px] transition-all flex justify-center items-center gap-2">
                Ver Productos
                <ShoppingBag className="w-5 h-5" />
              </button>
              <button className="bg-white dark:bg-surface-dark border-2 border-primary/20 dark:border-primary/10 text-text-light dark:text-white px-8 py-4 rounded-xl font-bold text-lg hover:border-primary hover:text-primary transition-all flex justify-center items-center gap-2">
                Nuestra Historia
                <ScrollText className="w-5 h-5" />
              </button>
            </div>
            
            <div className="flex items-center gap-6 pt-4">
              <div className="flex flex-col">
                <span className="text-3xl font-bold text-text-light dark:text-white font-display">40g</span>
                <span className="text-sm text-gray-500 dark:text-gray-400">Proteína</span>
              </div>
              <div className="w-px h-10 bg-gray-300 dark:bg-gray-700"></div>
              <div className="flex flex-col">
                <span className="text-3xl font-bold text-text-light dark:text-white font-display">0%</span>
                <span className="text-sm text-gray-500 dark:text-gray-400">Frituras</span>
              </div>
              <div className="w-px h-10 bg-gray-300 dark:bg-gray-700"></div>
              <div className="flex flex-col">
                <span className="text-3xl font-bold text-text-light dark:text-white font-display">100%</span>
                <span className="text-sm text-gray-500 dark:text-gray-400">Natural</span>
              </div>
            </div>
          </div>

          {/* Image Content */}
          <div className="order-1 lg:order-2 relative">
            <div className="relative z-10 animate-float">
              <img 
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuByK-1AH9BoLgwyhOmfofyeO0iXyXlq63Zn4Ifxhk8EoIvi7UF5za8YQKCorsivDrBOR9OIfMr4jYvf_Z0s1MV1pkuGS8bvAHKLVkr0m95f4072tP6jm_IGe_79IygMRypHh0oHvjVWbvMfEg8CXUJbMriY_suYpLDwtNGgwL2upBToWAJwdZHoggx1TLIFrnv1xip-hSLxzRQTifECaGDscMru0PfOsoRzFSDfXO8g3-d3Rl-TcUrZ3L41jZO0LU6FN0PqZ7fDo7Y" 
                alt="Bowl of healthy crispy legume snacks" 
                className="rounded-[2rem] shadow-2xl object-cover w-full h-[500px] transform rotate-2 hover:rotate-0 transition-transform duration-500"
              />
            </div>
            
            {/* Decoration Blobs */}
            <div className="absolute -bottom-10 -left-10 w-40 h-40 bg-secondary/30 rounded-full blur-2xl z-0"></div>
            <div className="absolute -top-10 -right-10 w-40 h-40 bg-primary/30 rounded-full blur-2xl z-0"></div>
            
            {/* Floating Card */}
            <div className="absolute -bottom-6 right-10 bg-white dark:bg-surface-dark p-4 rounded-2xl shadow-xl z-20 max-w-xs flex gap-3 items-center border border-gray-100 dark:border-gray-700">
              <div className="bg-primary/10 p-2 rounded-lg">
                <FlaskConical className="text-primary w-6 h-6" />
              </div>
              <div>
                <p className="text-xs text-gray-500 dark:text-gray-400 font-bold uppercase tracking-wider">Investigación</p>
                <p className="text-sm font-medium text-text-light dark:text-white">Prototipado Iterativo & Calidad</p>
              </div>
            </div>
          </div>
          
        </div>
      </div>
    </section>
  );
};