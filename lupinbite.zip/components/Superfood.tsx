import React from 'react';
import { Check } from 'lucide-react';

export const Superfood: React.FC = () => {
  return (
    <section className="py-20 bg-background-light dark:bg-background-dark overflow-hidden transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-primary rounded-[2.5rem] p-8 md:p-16 relative overflow-hidden">
          {/* Pattern Overlay */}
          <div className="absolute top-0 right-0 w-full h-full opacity-10 pointer-events-none" style={{ backgroundImage: 'radial-gradient(#fff 1px, transparent 1px)', backgroundSize: '20px 20px' }}></div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center relative z-10">
            <div>
              <h2 className="font-display text-3xl md:text-5xl font-bold text-white mb-6">El Superalimento de los Andes</h2>
              <p className="text-white/90 text-lg mb-8 leading-relaxed">
                El chocho es una leguminosa andina olvidada con un potencial increíble. Nosotros lo recuperamos en un formato moderno y delicioso.
              </p>
              
              <ul className="space-y-4">
                <li className="flex items-center text-white">
                  <div className="mr-3 bg-white/20 p-1 rounded-full">
                    <Check className="w-4 h-4" />
                  </div>
                  Alto contenido de calcio y hierro
                </li>
                <li className="flex items-center text-white">
                  <div className="mr-3 bg-white/20 p-1 rounded-full">
                    <Check className="w-4 h-4" />
                  </div>
                  Proteína vegetal completa
                </li>
                <li className="flex items-center text-white">
                   <div className="mr-3 bg-white/20 p-1 rounded-full">
                    <Check className="w-4 h-4" />
                  </div>
                  Cultivo sostenible
                </li>
              </ul>
            </div>
            
            <div className="relative flex justify-center">
              <div className="relative w-64 h-64 md:w-80 md:h-80 bg-white/10 rounded-full flex items-center justify-center backdrop-blur-sm border border-white/20">
                <img 
                  src="https://lh3.googleusercontent.com/aida-public/AB6AXuDdSNvxbRazxELAIGrdxHnfYK9wybtVsbuEabicQQ3BZCPbLQOBwZYpt9oATySzym0h6TEkw3b9d1D6DXDfQlY2dUT6hN3L_Pw68SQm_FEt7sJFDSQTMG2ce0Eg0KNGvv7deuGrBEEYLdPqR8UnmjJ8KAO8FvwA3fqzCm8ZC7TbPKfQO6IXG5ny_BBpXG5lNH_Y6Pk5SANb9MHmVgF-dr1asFFOMCK3l4_9dvalj79WcCSi6wxPHyeJEtMBv3mJglLyps5W3F6avtk" 
                  alt="Lupin beans seeds texture" 
                  className="w-56 h-56 md:w-72 md:h-72 object-cover rounded-full shadow-2xl"
                />
                <div className="absolute -top-4 right-0 bg-white text-primary px-4 py-1 rounded-full text-sm font-bold shadow-lg transform rotate-6">
                  Lupinus mutabilis
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};