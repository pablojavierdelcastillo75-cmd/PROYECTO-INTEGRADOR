import React from 'react';

export const Newsletter: React.FC = () => {
  return (
    <section className="py-20 bg-background-light dark:bg-background-dark transition-colors duration-300">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h2 className="font-display text-4xl md:text-5xl font-bold text-text-light dark:text-white mb-6">¿Listo para probar el futuro?</h2>
        <p className="text-xl text-gray-600 dark:text-gray-300 mb-10 max-w-2xl mx-auto">
          Sé parte de la revolución del chocho. Suscríbete para recibir noticias sobre el lanzamiento de nuestros prototipos.
        </p>
        
        <form className="max-w-md mx-auto flex flex-col sm:flex-row gap-4" onSubmit={(e) => e.preventDefault()}>
          <input 
            type="email" 
            placeholder="Tu correo electrónico" 
            className="flex-1 px-6 py-4 rounded-xl border-2 border-gray-200 dark:border-gray-700 bg-white dark:bg-surface-dark text-text-light dark:text-white focus:border-primary focus:ring-primary focus:outline-none transition-colors"
          />
          <button type="submit" className="bg-primary text-white px-8 py-4 rounded-xl font-bold hover:bg-opacity-90 transition-all shadow-lg hover:shadow-primary/30">
            Suscribirme
          </button>
        </form>
        
        <p className="mt-4 text-xs text-gray-500 dark:text-gray-500">
          Respetamos tu privacidad. Sin spam.
        </p>
      </div>
    </section>
  );
};