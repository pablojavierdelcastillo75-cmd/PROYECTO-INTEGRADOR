import React from 'react';
import { Microscope, ShieldCheck, ChefHat } from 'lucide-react';

export const Innovation: React.FC = () => {
  return (
    <section id="innovacion" className="py-20 bg-white dark:bg-surface-dark relative transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-primary font-bold uppercase tracking-widest text-sm mb-2">Ciencia y Sabor</h2>
          <h3 className="font-display text-3xl md:text-4xl font-bold text-text-light dark:text-white mb-4">Nuestra Innovación</h3>
          <p className="text-gray-600 dark:text-gray-300">
            Un proceso riguroso de investigación y desarrollo para transformar el <span className="italic">Lupinus mutabilis</span> en el snack perfecto.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Card 1 */}
          <div className="bg-background-light dark:bg-background-dark p-8 rounded-2xl border border-gray-100 dark:border-gray-800 hover:shadow-xl transition-all duration-300 group">
            <div className="w-14 h-14 bg-primary text-white rounded-xl flex items-center justify-center mb-6 shadow-lg shadow-primary/30 group-hover:scale-110 transition-transform">
              <Microscope className="w-8 h-8" />
            </div>
            <h4 className="font-display text-xl font-bold text-text-light dark:text-white mb-3">Prototipado Iterativo</h4>
            <p className="text-gray-600 dark:text-gray-400 text-sm leading-relaxed">
              Desarrollamos múltiples formulaciones definiendo parámetros precisos de proceso y criterios de calidad sensorial-descriptiva, evaluados rigurosamente por nuestro equipo técnico.
            </p>
          </div>

          {/* Card 2 */}
          <div className="bg-background-light dark:bg-background-dark p-8 rounded-2xl border border-gray-100 dark:border-gray-800 hover:shadow-xl transition-all duration-300 group">
            <div className="w-14 h-14 bg-secondary text-white rounded-xl flex items-center justify-center mb-6 shadow-lg shadow-secondary/30 group-hover:scale-110 transition-transform">
              <ShieldCheck className="w-8 h-8" />
            </div>
            <h4 className="font-display text-xl font-bold text-text-light dark:text-white mb-3">Inocuidad Garantizada</h4>
            <p className="text-gray-600 dark:text-gray-400 text-sm leading-relaxed">
              Revisión documental exhaustiva de inocuidad y benchmarking competitivo. Seguimos las últimas recomendaciones de formulación (Ramírez-Navas et al., 2024).
            </p>
          </div>

          {/* Card 3 */}
          <div className="bg-background-light dark:bg-background-dark p-8 rounded-2xl border border-gray-100 dark:border-gray-800 hover:shadow-xl transition-all duration-300 group">
            <div className="w-14 h-14 bg-text-light text-white rounded-xl flex items-center justify-center mb-6 shadow-lg shadow-gray-500/30 group-hover:scale-110 transition-transform">
              <ChefHat className="w-8 h-8" />
            </div>
            <h4 className="font-display text-xl font-bold text-text-light dark:text-white mb-3">Horneado, No Frito</h4>
            <p className="text-gray-600 dark:text-gray-400 text-sm leading-relaxed">
              Nuestra tecnología de horneado conserva las propiedades nutricionales del chocho, eliminando el exceso de grasas saturadas típicas de los snacks convencionales.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};