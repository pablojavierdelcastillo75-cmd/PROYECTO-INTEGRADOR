import React from 'react';

const FlavorCard: React.FC<{
  title: string;
  subtitle: string;
  description: string;
  imgSrc: string;
  accentColor: string;
  gradientClass: string;
  textColorClass: string;
}> = ({ title, subtitle, description, imgSrc, gradientClass, textColorClass }) => {
  return (
    <div className="group h-full">
      <div className="relative bg-background-light dark:bg-background-dark rounded-[2rem] p-8 border border-gray-100 dark:border-gray-800 transition-all duration-300 group-hover:shadow-2xl group-hover:-translate-y-2 overflow-hidden text-center h-full flex flex-col justify-between">
        <div>
          {/* Top Gradient */}
          <div className={`absolute top-0 inset-x-0 h-48 ${gradientClass} rounded-t-[2rem]`}></div>
          
          {/* Product Image */}
          <div className="relative z-10 mb-8 mt-2 h-72 flex items-center justify-center">
            <img 
              src={imgSrc} 
              alt={`LupinBite ${title}`} 
              className="h-full w-auto object-contain bag-shadow transform group-hover:scale-105 group-hover:rotate-1 transition-all duration-500"
            />
          </div>
          
          {/* Content */}
          <h4 className="font-display text-2xl font-bold text-text-light dark:text-white mb-2">{title}</h4>
          <p className={`${textColorClass} font-medium text-sm uppercase tracking-wider mb-4`}>{subtitle}</p>
          <p className="text-gray-600 dark:text-gray-400 mb-6">
            {description}
          </p>
        </div>
        
        <button className="w-full py-3 rounded-xl border-2 border-primary text-primary font-bold hover:bg-primary hover:text-white transition-colors">
          Ver Detalles
        </button>
      </div>
    </div>
  );
};

export const Flavors: React.FC = () => {
  return (
    <section id="sabores" className="py-24 bg-white dark:bg-surface-dark relative transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-primary font-bold uppercase tracking-widest text-sm mb-2">Colección Artesanal</h2>
          <h3 className="font-display text-4xl md:text-5xl font-bold text-text-light dark:text-white mb-6">Nuestros Sabores</h3>
          <p className="text-gray-600 dark:text-gray-300 text-lg">
            Tres variedades inspiradas en la naturaleza. Cada una diseñada para resaltar la textura crujiente de nuestro chocho horneado.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 lg:gap-12">
          <FlavorCard
            title="Sal Marina"
            subtitle="Blue & Cream Edition"
            description="La pureza de la sal marina en grano realza el sabor natural a nuez del chocho. Simple y perfecto."
            imgSrc="https://lh3.googleusercontent.com/aida-public/AB6AXuDNpH0yk0VE1tFpDVvNIaf5kJCNGZSmrlFzASv4QfdEXRoMnBCii4y2AwyBSlCGlkqZwrGb9jQ4PZprkKozoI0GmT9-GeqalqOYb4iaGJyjxUkG5DfJ3Nt0TLq9mR_YphG-9fxrJN5L46ln3H8EFwQqwgbilVhGUd-ky5nOu2Z-udAPxXfO916G0VF1O2MF8BofR8TWUSoJwZysaFA3ERbf29vIlHK8DZ1S4qtv-EgcBRMTJaY7N2qhhFnZEwOr6zjX8llbs5XB2Tc"
            accentColor="text-blue-500"
            gradientClass="bg-gradient-to-b from-blue-50/80 to-transparent dark:from-blue-900/20"
            textColorClass="text-blue-500"
          />
          <FlavorCard
            title="Chili Limón"
            subtitle="Red & Orange Edition"
            description="Una explosión cítrica con un toque picante balanceado. Para los que buscan intensidad."
            imgSrc="https://lh3.googleusercontent.com/aida-public/AB6AXuC6McccBtQwIjv1JXYsai9XA0VJB6XkR7LWspB4OhMGAMpAJfbZQmT0HCELDxSXkUxbla8Ljy0s0VKwqTgAYQYdC6-Y8tSeUh8HU04UTdgWV3KWWyJJacQmH9J7DY9pH1j_2QCpghAgdTCiLyVl2VXFoQxKWAMAjv2CVOpNWZVtuTfvE4Rv3U4aGE2yR2DjiT2C-n1s5fLL-LwdXY7-dzsDBWygHAh_mYiFfBwnPxGwIQiKiR3_Nd1B_hRulu_n_rtkU4JR8Mo7F68"
            accentColor="text-secondary"
            gradientClass="bg-gradient-to-b from-orange-50/80 to-transparent dark:from-orange-900/20"
            textColorClass="text-secondary"
          />
          <FlavorCard
            title="Hierbas Finas"
            subtitle="Green & Cream Edition"
            description="Una selección aromática de orégano, albahaca y romero. Frescura andina en cada bocado."
            imgSrc="https://lh3.googleusercontent.com/aida-public/AB6AXuB28KSiaJ1FYOzH39pVpTllYyZXNNhZ8BzFwGHuB2RKdE_jXxSEygBO9jNL8vztbIp_szP6Do-MP6_uRc2XXfle3t7K3n83kerVK4OXiO6JnjJdOGYw40LHVohBO8xROexr155aoL9OdSauYPGpJNU60hrwROmA7yP_zzDZJZyykFI-VeO39uDCU-NgGwjQEPaeoWmIsn_A8JBqhndM7hpOYpoB3uEAd6IBBEqYyILf2AlzNECoQ3sauyfL4i_0zbEMyNDR0ntTWz8"
            accentColor="text-primary"
            gradientClass="bg-gradient-to-b from-green-50/80 to-transparent dark:from-green-900/20"
            textColorClass="text-primary"
          />
        </div>
      </div>
    </section>
  );
};