import React from 'react';
import { Store, Tag, Truck, Send } from 'lucide-react';

export const Wholesale: React.FC = () => {
  return (
    <section id="mayoristas" className="py-24 bg-background-light dark:bg-background-dark transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white dark:bg-surface-dark rounded-[3rem] p-8 md:p-16 shadow-2xl border border-gray-100 dark:border-gray-800 relative overflow-hidden">
          {/* Decor element */}
          <div className="absolute top-0 right-0 -mt-20 -mr-20 w-96 h-96 bg-secondary/10 rounded-full blur-3xl pointer-events-none"></div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 relative z-10">
            {/* Info */}
            <div className="flex flex-col justify-center">
              <span className="flex items-center gap-2 text-primary font-bold uppercase tracking-widest text-sm mb-4">
                <Store className="w-5 h-5" />
                Para Negocios
              </span>
              <h2 className="font-display text-4xl md:text-5xl font-bold text-text-light dark:text-white mb-6">Pedidos al por Mayor</h2>
              <p className="text-gray-600 dark:text-gray-300 text-lg mb-8 leading-relaxed">
                Lleva la innovación del chocho a tus estantes. Ofrecemos condiciones exclusivas para distribuidores, tiendas especializadas y cadenas de retail.
              </p>
              
              <div className="space-y-6 mb-10">
                <div className="flex gap-4 p-4 bg-background-light dark:bg-background-dark rounded-xl border border-primary/10">
                  <div className="bg-primary/20 p-3 h-fit rounded-lg text-primary">
                    <Tag className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="font-bold text-text-light dark:text-white text-lg">Precios Competitivos</h4>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Escalas de descuento por volumen de compra y margen garantizado.</p>
                  </div>
                </div>
                
                <div className="flex gap-4 p-4 bg-background-light dark:bg-background-dark rounded-xl border border-secondary/10">
                  <div className="bg-secondary/20 p-3 h-fit rounded-lg text-secondary">
                    <Truck className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="font-bold text-text-light dark:text-white text-lg">Logística Flexible</h4>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Envíos a nivel nacional con tiempos de entrega optimizados.</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Form */}
            <div className="bg-gray-50 dark:bg-background-dark p-8 rounded-3xl border border-gray-100 dark:border-gray-700">
              <h3 className="font-display text-2xl font-bold text-text-light dark:text-white mb-6">Contáctanos</h3>
              <form className="space-y-4" onSubmit={(e) => e.preventDefault()}>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Nombre</label>
                    <input type="text" className="w-full bg-white dark:bg-surface-dark border border-gray-200 dark:border-gray-600 rounded-lg px-4 py-3 text-text-light dark:text-white focus:ring-2 focus:ring-primary focus:border-transparent outline-none transition-all" />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Empresa</label>
                    <input type="text" className="w-full bg-white dark:bg-surface-dark border border-gray-200 dark:border-gray-600 rounded-lg px-4 py-3 text-text-light dark:text-white focus:ring-2 focus:ring-primary focus:border-transparent outline-none transition-all" />
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Email Corporativo</label>
                  <input type="email" className="w-full bg-white dark:bg-surface-dark border border-gray-200 dark:border-gray-600 rounded-lg px-4 py-3 text-text-light dark:text-white focus:ring-2 focus:ring-primary focus:border-transparent outline-none transition-all" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Interés</label>
                  <select className="w-full bg-white dark:bg-surface-dark border border-gray-200 dark:border-gray-600 rounded-lg px-4 py-3 text-gray-600 dark:text-gray-300 focus:ring-2 focus:ring-primary focus:border-transparent outline-none transition-all">
                    <option>Distribución Retail</option>
                    <option>Ventas HORECA</option>
                    <option>Marca Blanca</option>
                    <option>Otro</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Mensaje</label>
                  <textarea rows={3} className="w-full bg-white dark:bg-surface-dark border border-gray-200 dark:border-gray-600 rounded-lg px-4 py-3 text-text-light dark:text-white focus:ring-2 focus:ring-primary focus:border-transparent outline-none transition-all"></textarea>
                </div>
                <button className="w-full bg-text-light dark:bg-white text-white dark:text-text-light font-bold py-4 rounded-xl hover:bg-opacity-90 transition-all shadow-lg flex justify-center items-center gap-2">
                  Solicitar Información
                  <Send className="w-4 h-4" />
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};