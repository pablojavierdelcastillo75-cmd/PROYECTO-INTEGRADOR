import React from 'react';
import { Handshake, Users, Gavel, ArrowRight } from 'lucide-react';

export const Community: React.FC = () => {
  return (
    <section id="comunidad" className="py-24 bg-white dark:bg-surface-dark transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          
          {/* Image Side */}
          <div className="relative">
            <img 
              src="https://lh3.googleusercontent.com/aida-public/AB6AXuDzpE2PmbY95mfP0nTrDSGnOt4huAkt4pO843zN1ljApSkQx1bm__wTHi7Mi0er2M8JnG3fBtpDsfURU8OxdcVb9hcPec50TEYjpQvuO97OU1F0keECFPwnjZ2FGh0vessZgWF6Rbezs6QAGa-G6_YEkJ-Saqska6b46WdWMwGFYRetqNGOESXF-LCBIwzshczIJ-xXUouAg-Muw4TPAOgjjZhNgSTcGVlRtQwBWSLjlWDpYE9MpRIAh0Oql6yF54dGwzLqJlGfiFE" 
              alt="Community hands working together in agriculture" 
              className="rounded-2xl shadow-2xl object-cover h-[500px] w-full grayscale-[20%] hover:grayscale-0 transition-all duration-500"
            />
            <div className="absolute bottom-6 left-6 right-6 bg-background-light/95 dark:bg-background-dark/95 backdrop-blur-md p-6 rounded-xl border border-primary/20 shadow-lg">
              <div className="flex items-center gap-4">
                <div className="bg-secondary/20 p-3 rounded-full text-secondary">
                  <Handshake className="w-6 h-6" />
                </div>
                <div>
                  <h5 className="font-bold text-text-light dark:text-white">Alianzas Estratégicas</h5>
                  <p className="text-xs text-gray-500 dark:text-gray-400">Ministerio de Inclusión Económica y Social</p>
                </div>
              </div>
            </div>
          </div>
          
          {/* Text Side */}
          <div>
            <span className="text-secondary font-bold uppercase tracking-widest text-sm mb-2 block">Impacto Real</span>
            <h2 className="font-display text-4xl font-bold text-text-light dark:text-white mb-6">Compromiso Social y Comunitario</h2>
            <p className="text-gray-600 dark:text-gray-300 mb-6 leading-relaxed">
              Nuestro proyecto va más allá del snack. Incorporamos una revisión normativa exhaustiva para la articulación con organizaciones sociales como <span className="font-bold text-primary">potenciales aliadas</span> de abastecimiento y trabajo comunitario.
            </p>
            <p className="text-gray-600 dark:text-gray-300 mb-8 leading-relaxed">
              Cumplimos con toda la base legal y documentación mínima para la constitución y registro, asegurando un modelo de negocio justo y transparente que beneficia a los productores locales.
            </p>
            
            <div className="space-y-4">
              <div className="flex items-start">
                <Users className="text-primary mt-1 mr-4 w-6 h-6" />
                <div>
                  <h4 className="font-bold text-text-light dark:text-white">Trabajo Comunitario</h4>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Fomentamos el desarrollo económico local.</p>
                </div>
              </div>
              <div className="flex items-start">
                <Gavel className="text-primary mt-1 mr-4 w-6 h-6" />
                <div>
                  <h4 className="font-bold text-text-light dark:text-white">Cumplimiento Normativo</h4>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Alineados con el Ministerio de Desarrollo Humano.</p>
                </div>
              </div>
            </div>
            
            <div className="mt-10">
              <a href="#" className="inline-flex items-center text-primary font-bold hover:text-secondary transition-colors group">
                Leer informe de impacto
                <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </a>
            </div>
          </div>
          
        </div>
      </div>
    </section>
  );
};