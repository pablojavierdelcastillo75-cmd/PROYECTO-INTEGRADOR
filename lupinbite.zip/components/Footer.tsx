import React from 'react';
import { Leaf, Facebook, Camera, AtSign, Heart } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-white dark:bg-surface-dark border-t border-gray-100 dark:border-gray-800 pt-16 pb-8 transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          {/* Brand */}
          <div className="col-span-1 md:col-span-1">
            <div className="flex items-center space-x-2 mb-6">
              <Leaf className="text-primary w-6 h-6" strokeWidth={2.5} />
              <span className="font-display font-bold text-xl text-text-light dark:text-white">
                Lupin<span className="text-primary">Bite</span>
              </span>
            </div>
            <p className="text-sm text-gray-500 dark:text-gray-400 mb-6">
              Innovación alimentaria basada en la biodiversidad andina.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-primary transition-colors"><Facebook className="w-5 h-5" /></a>
              <a href="#" className="text-gray-400 hover:text-primary transition-colors"><Camera className="w-5 h-5" /></a>
              <a href="#" className="text-gray-400 hover:text-primary transition-colors"><AtSign className="w-5 h-5" /></a>
            </div>
          </div>

          {/* Links 1 */}
          <div>
            <h4 className="font-bold text-text-light dark:text-white mb-4">Producto</h4>
            <ul className="space-y-2 text-sm text-gray-600 dark:text-gray-400">
              <li><a href="#" className="hover:text-primary transition-colors">Ingredientes</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Proceso</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Nutrición</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Dónde Comprar</a></li>
            </ul>
          </div>

          {/* Links 2 */}
          <div>
            <h4 className="font-bold text-text-light dark:text-white mb-4">Compañía</h4>
            <ul className="space-y-2 text-sm text-gray-600 dark:text-gray-400">
              <li><a href="#" className="hover:text-primary transition-colors">Sobre Nosotros</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Impacto Social</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Blog</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Contacto</a></li>
            </ul>
          </div>

          {/* Links 3 */}
          <div>
            <h4 className="font-bold text-text-light dark:text-white mb-4">Legal</h4>
            <ul className="space-y-2 text-sm text-gray-600 dark:text-gray-400">
              <li><a href="#" className="hover:text-primary transition-colors">Términos y Condiciones</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Política de Privacidad</a></li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-100 dark:border-gray-800 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-xs text-gray-500 dark:text-gray-500 mb-4 md:mb-0">
            © 2024 LupinBite. Todos los derechos reservados.
          </p>
          <div className="text-xs text-gray-400 flex items-center gap-1">
            <span>Hecho con</span> <Heart className="w-3 h-3 text-red-400 fill-red-400" /> <span>en los Andes</span>
          </div>
        </div>
      </div>
    </footer>
  );
};