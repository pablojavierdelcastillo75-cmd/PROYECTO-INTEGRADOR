import React from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { Innovation } from './components/Innovation';
import { Superfood } from './components/Superfood';
import { Flavors } from './components/Flavors';
import { Wholesale } from './components/Wholesale';
import { Community } from './components/Community';
import { Newsletter } from './components/Newsletter';
import { Footer } from './components/Footer';

function App() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-grow">
        <Hero />
        <Innovation />
        <Superfood />
        <Flavors />
        <Wholesale />
        <Community />
        <Newsletter />
      </main>
      <Footer />
    </div>
  );
}

export default App;